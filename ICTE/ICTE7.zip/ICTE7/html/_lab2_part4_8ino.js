var _lab2_part4_8ino =
[
    [ "loop", "_lab2_part4_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_lab2_part4_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "check", "_lab2_part4_8ino.html#a08e5d4acf3bed996e35f8c4354412bcf", null ],
    [ "count", "_lab2_part4_8ino.html#ad43c3812e6d13e0518d9f8b8f463ffcf", null ],
    [ "startTime", "_lab2_part4_8ino.html#a8ad49a66e91d8658c5f1f7dbcbcbbd2f", null ]
];