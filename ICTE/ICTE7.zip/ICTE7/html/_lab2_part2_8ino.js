var _lab2_part2_8ino =
[
    [ "LED_PIN", "_lab2_part2_8ino.html#ab4553be4db9860d940f81d7447173b2f", null ],
    [ "loop", "_lab2_part2_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_lab2_part2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "interval", "_lab2_part2_8ino.html#a2e243d502b1d882c3b827c6b070cc02c", null ],
    [ "lastToggleTime", "_lab2_part2_8ino.html#aeb0a8392e32d9afccd84415c9fa390e1", null ]
];