var searchData=
[
  ['check_0',['check',['../_lab2_part4_8ino.html#a08e5d4acf3bed996e35f8c4354412bcf',1,'Lab2Part4.ino']]],
  ['count_1',['count',['../_lab2_part4_8ino.html#ad43c3812e6d13e0518d9f8b8f463ffcf',1,'Lab2Part4.ino']]]
];
