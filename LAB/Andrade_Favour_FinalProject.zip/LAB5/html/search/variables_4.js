var searchData=
[
  ['joystick_5fx_5fpin_0',['joystick_x_pin',['../_final_project___debug_or_segfault_8ino.html#a9ae5f8f5407f6cf8acea1efc7a28dad4',1,'FinalProject_DebugOrSegfault.ino']]],
  ['joystickgametaskhandle_1',['JoystickGameTaskHandle',['../_final_project___debug_or_segfault_8ino.html#a583e61790b3703356e2edae4756364cb',1,'FinalProject_DebugOrSegfault.ino']]],
  ['joystickinputtaskhandle_2',['JoystickInputTaskHandle',['../_final_project___debug_or_segfault_8ino.html#acb4faeb145377429b57163d2c30b990b',1,'FinalProject_DebugOrSegfault.ino']]],
  ['joystickrunning_3',['joystickRunning',['../_final_project___debug_or_segfault_8ino.html#a557df7907d596361e50b13aa780c3086',1,'FinalProject_DebugOrSegfault.ino']]],
  ['joystickstart_4',['joystickStart',['../_final_project___debug_or_segfault_8ino.html#af0b364aae7aed3f5e476d4da5614aef4',1,'FinalProject_DebugOrSegfault.ino']]],
  ['joystickwin_5',['joystickWin',['../_final_project___debug_or_segfault_8ino.html#a55f1c711c14eb0481e1a0ac75ca97b70',1,'FinalProject_DebugOrSegfault.ino']]]
];
