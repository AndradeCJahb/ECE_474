var searchData=
[
  ['serialrtctaskhandle_0',['SerialRTCTaskHandle',['../_final_project___debug_or_segfault_8ino.html#ae5bfe11ff1a8e94d1918928f951cddeb',1,'FinalProject_DebugOrSegfault.ino']]]
];
