var searchData=
[
  ['buzzertimetask_0',['BuzzerTimeTask',['../_final_project___debug_or_segfault_8ino.html#aa468e664b789dd79fcd209d598c7aa23',1,'FinalProject_DebugOrSegfault.ino']]],
  ['buzzertimetaskhandle_1',['BuzzerTimeTaskHandle',['../_final_project___debug_or_segfault_8ino.html#a7482ebb07a001d26466833df601ae313',1,'FinalProject_DebugOrSegfault.ino']]]
];
