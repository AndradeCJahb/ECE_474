var searchData=
[
  ['win_0',['win',['../_final_project___debug_or_segfault_8ino.html#a267de1172374b2ece9b338aeeab9cb09',1,'FinalProject_DebugOrSegfault.ino']]]
];
