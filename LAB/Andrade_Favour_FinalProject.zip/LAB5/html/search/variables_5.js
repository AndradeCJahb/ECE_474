var searchData=
[
  ['lose_0',['lose',['../_final_project___debug_or_segfault_8ino.html#a5c625d4e340a06add32f9025bea041d8',1,'FinalProject_DebugOrSegfault.ino']]]
];
