var searchData=
[
  ['serialrtcinputtask_0',['SerialRTCInputTask',['../_final_project___debug_or_segfault_8ino.html#ab895ed75a09efb92402fe1069ea0d260',1,'FinalProject_DebugOrSegfault.ino']]],
  ['setup_1',['setup',['../_final_project___debug_or_segfault_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'FinalProject_DebugOrSegfault.ino']]]
];
