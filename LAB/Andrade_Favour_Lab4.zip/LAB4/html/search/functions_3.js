var searchData=
[
  ['primecalculationtask_0',['PrimeCalculationTask',['../_lab4_part2_8ino.html#a7e92600363f394090674db32717f6313',1,'Lab4Part2.ino']]]
];
