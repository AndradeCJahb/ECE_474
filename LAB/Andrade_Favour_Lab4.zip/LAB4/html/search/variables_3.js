var searchData=
[
  ['primecalculationtaskhandle_0',['PrimeCalculationTaskHandle',['../_lab4_part2_8ino.html#ab3950d09c989147f9dc6e6b3f7904985',1,'Lab4Part2.ino']]]
];
