var searchData=
[
  ['ledtaskexecutiontime_0',['ledTaskExecutionTime',['../_lab4_part1_8ino.html#a75818cb094cf69f33e62ddf759c8daab',1,'Lab4Part1.ino']]],
  ['ledtaskhandle_1',['ledTaskHandle',['../_lab4_part1_8ino.html#a9227c54721d0ff94543483e0faece60e',1,'Lab4Part1.ino']]],
  ['lightdetectortaskhandle_2',['LightDetectorTaskHandle',['../_lab4_part2_8ino.html#a5fed94c17cd89aa00dc05ba58af7170f',1,'Lab4Part2.ino']]],
  ['lightlevel_3',['lightLevel',['../_lab4_part2_8ino.html#ac9e32a0f7b89baa001e7d583ae644f87',1,'Lab4Part2.ino']]],
  ['lightleveldisplaytaskhandle_4',['LightLevelDisplayTaskHandle',['../_lab4_part2_8ino.html#a4c231020fbc438140fdeb2b4e39d1d26',1,'Lab4Part2.ino']]]
];
