var searchData=
[
  ['scheduletasks_0',['scheduleTasks',['../_lab4_part1_8ino.html#a4ea4585de20507653ce66667bb133d6f',1,'Lab4Part1.ino']]],
  ['setup_1',['setup',['../_lab4_part1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Lab4Part1.ino'],['../_lab4_part2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Lab4Part2.ino']]]
];
