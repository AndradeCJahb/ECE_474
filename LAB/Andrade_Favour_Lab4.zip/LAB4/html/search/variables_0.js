var searchData=
[
  ['alphabettaskexecutiontime_0',['alphabetTaskExecutionTime',['../_lab4_part1_8ino.html#ae03e873e30fb2f78c6292fc4e2614e54',1,'Lab4Part1.ino']]],
  ['alphabettaskhandle_1',['alphabetTaskHandle',['../_lab4_part1_8ino.html#af4202b14fffd45682aa00a448a732502',1,'Lab4Part1.ino']]],
  ['anomalyalarmtaskhandle_2',['AnomalyAlarmTaskHandle',['../_lab4_part2_8ino.html#afa7174ecd72a27769e093df541de8925',1,'Lab4Part2.ino']]]
];
