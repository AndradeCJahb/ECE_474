var searchData=
[
  ['scheduletaskshandle_0',['scheduleTasksHandle',['../_lab4_part1_8ino.html#a2daae7f6603aaddb5541fd720b60ce7a',1,'Lab4Part1.ino']]],
  ['semaphorehandle_1',['semaphoreHandle',['../_lab4_part2_8ino.html#a5899905f6a34542e7abf5651ac20ef30',1,'Lab4Part2.ino']]],
  ['sma_2',['SMA',['../_lab4_part2_8ino.html#aa2fab38224cee40a802890f3a8bdba5e',1,'Lab4Part2.ino']]]
];
