var _lab4_part2_8ino =
[
    [ "BUZZER_PIN", "_lab4_part2_8ino.html#ab61d0981ed42df9e18211b273d22cfcd", null ],
    [ "AnomalyAlarmTask", "_lab4_part2_8ino.html#a7a78d096b7238df072738dda8b18f257", null ],
    [ "lcd", "_lab4_part2_8ino.html#ae084e1bc8ccb35ea289ba0ca4972ea6d", null ],
    [ "LightDetectorTask", "_lab4_part2_8ino.html#aad67a1a52e591d71933d936c283a473f", null ],
    [ "LightLevelDisplayTask", "_lab4_part2_8ino.html#a51d460dc58c9a188c74767ba9454a0ae", null ],
    [ "PrimeCalculationTask", "_lab4_part2_8ino.html#a7e92600363f394090674db32717f6313", null ],
    [ "setup", "_lab4_part2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "AnomalyAlarmTaskHandle", "_lab4_part2_8ino.html#afa7174ecd72a27769e093df541de8925", null ],
    [ "LightDetectorTaskHandle", "_lab4_part2_8ino.html#a5fed94c17cd89aa00dc05ba58af7170f", null ],
    [ "lightLevel", "_lab4_part2_8ino.html#ac9e32a0f7b89baa001e7d583ae644f87", null ],
    [ "LightLevelDisplayTaskHandle", "_lab4_part2_8ino.html#a4c231020fbc438140fdeb2b4e39d1d26", null ],
    [ "PrimeCalculationTaskHandle", "_lab4_part2_8ino.html#ab3950d09c989147f9dc6e6b3f7904985", null ],
    [ "semaphoreHandle", "_lab4_part2_8ino.html#a5899905f6a34542e7abf5651ac20ef30", null ],
    [ "SMA", "_lab4_part2_8ino.html#aa2fab38224cee40a802890f3a8bdba5e", null ]
];