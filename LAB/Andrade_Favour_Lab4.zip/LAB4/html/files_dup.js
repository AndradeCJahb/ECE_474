var files_dup =
[
    [ "Lab4Part1", "dir_6cbbff20cec2f238cdc4a1d22de51e81.html", "dir_6cbbff20cec2f238cdc4a1d22de51e81" ],
    [ "Lab4Part2", "dir_2e145cda4e1cc7c71ef7cab5dee0b115.html", "dir_2e145cda4e1cc7c71ef7cab5dee0b115" ]
];