var _lab4_part1_8ino =
[
    [ "LED_PIN", "_lab4_part1_8ino.html#ab4553be4db9860d940f81d7447173b2f", null ],
    [ "alphabetTask", "_lab4_part1_8ino.html#a4d773b0b523ff172ed84864533f5b4eb", null ],
    [ "counterTask", "_lab4_part1_8ino.html#a2b4338007e5668fd56dfe3f333fc26d2", null ],
    [ "lcd", "_lab4_part1_8ino.html#ae084e1bc8ccb35ea289ba0ca4972ea6d", null ],
    [ "ledTask", "_lab4_part1_8ino.html#aa3845dae865c47cfdfe37652a373aa2a", null ],
    [ "scheduleTasks", "_lab4_part1_8ino.html#a4ea4585de20507653ce66667bb133d6f", null ],
    [ "setup", "_lab4_part1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "alphabetTaskExecutionTime", "_lab4_part1_8ino.html#ae03e873e30fb2f78c6292fc4e2614e54", null ],
    [ "alphabetTaskHandle", "_lab4_part1_8ino.html#af4202b14fffd45682aa00a448a732502", null ],
    [ "counterTaskExecutionTime", "_lab4_part1_8ino.html#a2e782932f0bf2f1fa35ac3bfa9a8b5cc", null ],
    [ "counterTaskHandle", "_lab4_part1_8ino.html#a2294463b35775d51e1151a1c86a05f58", null ],
    [ "ledTaskExecutionTime", "_lab4_part1_8ino.html#a75818cb094cf69f33e62ddf759c8daab", null ],
    [ "ledTaskHandle", "_lab4_part1_8ino.html#a9227c54721d0ff94543483e0faece60e", null ],
    [ "remainingAlphabetTime", "_lab4_part1_8ino.html#a1fb03c229171c45dee3187903d2cbcf3", null ],
    [ "remainingCounterTime", "_lab4_part1_8ino.html#a562419e3d9d311efcc74859e5b3adf44", null ],
    [ "remainingLedTime", "_lab4_part1_8ino.html#a984bdb71413c08cf09f7d11793877dfa", null ],
    [ "scheduleTasksHandle", "_lab4_part1_8ino.html#a2daae7f6603aaddb5541fd720b60ce7a", null ]
];